export const createShowMoreButton = () => {
  return `<button class="films-list__show-more">Show more</button>`
}
