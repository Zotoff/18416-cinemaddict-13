export const createUserRank = () => {
  return `<p class="profile__rating">Movie Buff</p>`;
};
