export const createExtraFilmsList = () => {
  return `<section class="films-list films-list--extra">
    <div class="films-list__container">
    </div>
  </section>`;
};
