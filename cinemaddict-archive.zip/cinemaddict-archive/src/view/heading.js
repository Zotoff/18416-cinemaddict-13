export const createHeading = () => {
  return `<h2></h2>`;
};
