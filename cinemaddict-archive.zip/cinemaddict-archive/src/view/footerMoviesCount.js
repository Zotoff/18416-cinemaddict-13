export const createFooterMoviesCount = () => {
  return `<p>130 291 movies inside</p>`;
};
